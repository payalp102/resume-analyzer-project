from flask import Flask, render_template, request
import PyPDF2
import spacy
import os

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'

# Ensure uploads folder exists
if not os.path.exists('uploads'):
    os.makedirs('uploads')

nlp = spacy.load("en_core_web_sm")

# Extract text safely
def extract_text(file_path):
    text = ""
    try:
        reader = PyPDF2.PdfReader(file_path)
        for page in reader.pages:
            content = page.extract_text()
            if content:
                text += content
    except:
        return "ERROR"
    return text

# Skill extraction
def analyze_resume(text):
    keywords = ["python", "java", "sql", "Cloud Computing","data analyst", "data science"]
    skills = []

    for word in text.lower().split():
        if word in keywords:
            skills.append(word.capitalize())

    return list(set(skills))

# Score
def resume_score(skills):
    return min(len(skills) * 20, 100)

# Job recommendation
def recommend_job(skills):
    s = [i.lower() for i in skills]
    if "python" in s:
        return "Software Developer / Data Scientist"
    elif "java" in s:
        return "Backend Developer"
    else:
        return "General IT Role"

# Job match %
def job_match(skills):
    required = ["python", "sql", "machine learning"]
    s = [i.lower() for i in skills]
    match = sum(1 for i in required if i in s)
    return int((match / len(required)) * 100)

# Missing skills
def missing_skills(skills):
    required = ["python", "sql", "machine learning", "data science"]
    s = [i.lower() for i in skills]
    return [i for i in required if i not in s]

@app.route("/", methods=["GET", "POST"])
def index():
    skills = []
    job = ""
    score = 0
    match = 0
    missing = []

    if request.method == "POST":
        file = request.files.get("resume")

        if file and file.filename != "":
            path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(path)

            text = extract_text(path)

            if text == "ERROR":
                return render_template("index.html", error="Invalid PDF file")

            skills = analyze_resume(text)
            job = recommend_job(skills)
            score = resume_score(skills)
            match = job_match(skills)
            missing = missing_skills(skills)

    return render_template("index.html",
                           skills=skills,
                           job=job,
                           score=score,
                           match=match,
                           missing=missing,
                           error=None)

if __name__ == "__main__":
    app.run(debug=True)